function m=mid(m)
m = m;