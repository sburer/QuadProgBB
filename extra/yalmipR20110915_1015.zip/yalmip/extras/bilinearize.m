function [model,changed] = bilinearize(model)

error('OBSOLETE FUNCTION')
