function sys = sdp2mat(X,solution)
%SDP2MAT Obsolete, use double

% Author Johan L�fberg
% $Id: sdp2mat.m,v 1.1 2006-08-10 18:00:22 joloef Exp $

warning('sdp2mat is obsolete. Use double');
sys = double(X);