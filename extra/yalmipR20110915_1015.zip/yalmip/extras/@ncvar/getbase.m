function Q=getbase(X)
%GETBASE Internal function to extract all base matrices

% Author Johan L�fberg 
% $Id: getbase.m,v 1.1 2006-08-10 18:00:20 joloef Exp $  

Q=double(X.basis);
  
  
      