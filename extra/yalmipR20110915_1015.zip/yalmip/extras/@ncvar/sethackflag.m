function X = sethackflag(X,flag)
%GETHACKFLAG Internal function to set constraint type

% Author Johan L�fberg 
% $Id: sethackflag.m,v 1.1 2006-08-10 18:00:22 joloef Exp $  

X.typeflag = flag;
