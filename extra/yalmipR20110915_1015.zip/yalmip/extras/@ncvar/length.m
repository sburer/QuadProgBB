function n=length(X)
%LENGTH (overloaded)

% Author Johan L�fberg 
% $Id: length.m,v 1.1 2006-08-10 18:00:21 joloef Exp $   

n = max(X.dim);
