function f = deadhub(p,lambda)

f = -(invsathub(p,lambda)-lambda*abs(p));


