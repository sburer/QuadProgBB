function display(X)
%DISPLAY (overloaded)

% Author Johan L�fberg
% $Id: display.m,v 1.1 2005-10-12 16:05:54 joloef Exp $

disp('Basis object');
display(X.basis)
