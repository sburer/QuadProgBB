function y = ctranspose(X)
%PLUS (overloaded)

% Author Johan L�fberg
% $Id: transpose.m,v 1.1 2005-10-12 16:05:54 joloef Exp $

y = transpose(double(X));