function cx = getP(X)
%display           Overloaded

% Author Johan L�fberg 
% $Id: getP.m,v 1.1 2004-06-17 08:40:08 johanl Exp $  

cx = X.P;
