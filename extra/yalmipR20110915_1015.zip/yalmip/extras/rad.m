function m=rad(m)
m = m*0;