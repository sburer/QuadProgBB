function v = length(X)
% length (overloaded)

% Author Johan L�fberg
% $Id: length.m,v 1.1 2006-05-17 21:34:41 joloef Exp $

v = max(X.dim);